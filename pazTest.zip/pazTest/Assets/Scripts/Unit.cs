﻿using UnityEngine;
using System.Collections;

public class Unit : MonoBehaviour {
	
	// Use this for initialization
	void Start () {
	}

	// Update is called once per frame
	void Update () {

		if (Input.GetMouseButtonUp (0)) {
			gameObject.tag = "unit";
		}
	}

	public void MoveUnit(Vector3 pos)
	{
		gameObject.tag = "swap";
		gameObject.renderer.sortingOrder = 5;
		
		
		Hashtable table = new Hashtable ();
		table.Add ("x", 0.9f);
		table.Add ("time", 0.1f);
		table.Add ("easeType", "linear");
		
		Hashtable table2 = new Hashtable ();
		table2.Add ("y", -0.7f);
		table2.Add ("time", 0.05f);
		table2.Add ("easeType", "linear");
		
		Hashtable table3 = new Hashtable ();
		table3.Add ("y", 0.7f);
		table3.Add ("time", 0.05f);
		table3.Add ("delay", 0.05f);
		table3.Add ("easeType", "linear");
		
		Hashtable table4 = new Hashtable ();
		table4.Add ("x", -0.9f);
		table4.Add ("time", 0.1f);
		table4.Add ("easeType", "linear");

		Hashtable table5 = new Hashtable ();
		table5.Add ("y", 0.9f);
		table5.Add ("time", 0.1f);
		table5.Add ("easeType", "linear");
		
		Hashtable table6 = new Hashtable ();
		table6.Add ("x", 0.7f);
		table6.Add ("time", 0.05f);
		table6.Add ("easeType", "linear");
		
		Hashtable table7 = new Hashtable ();
		table7.Add ("x", -0.7f);
		table7.Add ("time", 0.05f);
		table7.Add ("delay", 0.05f);
		table7.Add ("easeType", "linear");
		
		Hashtable table8 = new Hashtable ();
		table8.Add ("y", -0.9f);
		table8.Add ("time", 0.1f);
		table8.Add ("easeType", "linear");

		table.Add ("oncomplete", "SwapUnitEnd");
		table.Add ("oncompleteparams", pos);
		table.Add ("oncompletetarget", this.gameObject);
		
		table4.Add ("oncomplete", "SwapUnitEnd");
		table4.Add ("oncompleteparams", pos);
		table4.Add ("oncompletetarget", this.gameObject);
		
		table5.Add ("oncomplete", "SwapUnitEnd");
		table5.Add ("oncompleteparams", pos);
		table5.Add ("oncompletetarget", this.gameObject);
		
		table8.Add ("oncomplete", "SwapUnitEnd");
		table8.Add ("oncompleteparams", pos);
		table8.Add ("oncompletetarget", this.gameObject);

		Hashtable table9 = new Hashtable ();
		table9.Add ("x", pos.x);
		table9.Add ("y", pos.y);
		table9.Add ("time", 0.1f);
		table9.Add ("easeType", "linear");
		
		table9.Add ("oncomplete", "SwapUnitEnd");
		table9.Add ("oncompleteparams", pos);
		table9.Add ("oncompletetarget", this.gameObject);

		if((transform.position.x < pos.x) && (transform.position.y == pos.y)){
			iTween.MoveBy (gameObject, table);
			iTween.MoveAdd (gameObject, table2);
			iTween.MoveAdd (gameObject, table3);
		}
		else if((transform.position.x > pos.x)&& (transform.position.y == pos.y)){

			iTween.MoveBy (gameObject, table4);
			iTween.MoveAdd (gameObject, table2);
			iTween.MoveAdd (gameObject, table3);
		}
		else if((transform.position.y < pos.y)&& (transform.position.x == pos.x)){
			iTween.MoveBy (gameObject, table5);
			iTween.MoveAdd (gameObject, table6);
			iTween.MoveAdd (gameObject, table7);
		}
		else if((transform.position.y > pos.y)&& (transform.position.x == pos.x)){
			iTween.MoveBy (gameObject, table8);
			iTween.MoveAdd (gameObject, table6);
			iTween.MoveAdd (gameObject, table7);
		}

		else{
			iTween.MoveTo (gameObject, table9);
		}

	}

	private void SwapUnitEnd(Vector3 pos)
	{
		gameObject.tag = ("unit");
		gameObject.renderer.sortingOrder = 0;

	}

	public Vector3 getPosition()
	{
		return transform.position;
	}
	
	public Vector3 GetPosition()
	{
		return transform.position;
	}
}