﻿using UnityEngine;
using System.Collections;

public class TestBlack : MonoBehaviour {

	Vector3 tmpPosition;
	private bool moveFlag = false;

	// Use this for initialization
	void Start () {
		tmpPosition = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 tapPoint = Input.mousePosition;

		var test = transform.position;
		test.x = Mathf.Clamp( Camera.main.ScreenToWorldPoint (new Vector3 (tapPoint.x, tapPoint.y, 10)).x,-2.7f,2.7f);
		test.y = Mathf.Clamp (Camera.main.ScreenToWorldPoint (new Vector3 (tapPoint.x, tapPoint.y, 10)).y, -4.3f, -0.7f);
		test.z = 10;

		gameObject.transform.position = test;
	}

	public Vector3 BlackPos()
	{
		return gameObject.transform.position;
	}


	void OnTriggerEnter2D(Collider2D collision){

		if (gameObject.tag == "black" && collision.tag == "unit") {
			moveFlag = true;

			Vector3 myPos = tmpPosition;
			Vector3 anotherPos = collision.gameObject.transform.position;

			if(Vector3.Distance(anotherPos,myPos) <= 1.5f){

				collision.GetComponent<Unit>().MoveUnit(tmpPosition);

				tmpPosition = collision.gameObject.transform.position;
			}

			Debug.Log("swap");
		}
	}

	public bool MoveFlag()
	{
		return moveFlag;
	}

	public void OffMoveFlag()
	{
		moveFlag = false;
	}

	public void DestroyBlack()
	{
		Destroy (gameObject);
	}
	
	public void Dead()
	{
		Destroy (gameObject);
	}

	public Vector3 TmpPosition()
	{
		return tmpPosition;
	}

}
