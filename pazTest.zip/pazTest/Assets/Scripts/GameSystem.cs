﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameSystem : MonoBehaviour {

	//unitParameter
	private const int UnitVerticalNum = 5;
	private const int UnitHorizonalNum = 7;
	private const float UnitSize = 0.9f;
	private const float FirstUnitPosX = -2.7f;
	private const float FirstUnitPosY = -4.3f;

	//timer
	private float timer = 4.0f;
	private bool timerFlag = false;

	//消去するユニットの塊
	private int[,] unitTable = new int[UnitVerticalNum, UnitHorizonalNum];
	private bool[,] deleteTable = new bool[UnitVerticalNum, UnitHorizonalNum];

	//追加するユニット
	public GameObject unitObj;  
	public Sprite[] units;

	//combo
	public GameObject comboNumObj; 
	public Sprite[] nums;
	public GameObject rengeki;
	private int comboCount = 1;
	private int comboNum = 0;
	List<GameObject> comboList = new List<GameObject>();
	List<GameObject> comboNumList = new List<GameObject>();
	private int deleteCount = 0;

	private int comboTes = 1;

	//掴んでいるユニットの変数
	public GameObject holdObj;
	public float holdPositionX;
	public float holdPositionY;
	private float z = 10f;
	private GameObject[,] unitSet;

	//RecreateUnit
	private float createPos = 0;

	//dimm
	public GameObject dimm;
	private bool isDimm = false;
	
	//mainloopflag
	private bool isMove = false;
	private bool isDelete = false;
	private float deleteTimer;
	private bool isUp = false;
	private float upTimer = 0.7f;
	private bool isLoop = false;
	private bool isDeleteUnit = true;
	private float comboTimer = 0;
	private float dimmTimer = 0;
	private bool setUnitFlag = false;
	private float setUnitTimer = 0.8f;

	float otherUnitPosX;
	float otherUnitPosY;

	public GameObject TestBlack;

	GameObject TestBlackMain;

	public GameObject countTimer;
	private GameObject CountTimer;

	void Start () {

		Application.targetFrameRate = 60;
		StartSetUnit ();
		 
	}

	/*
	void OnGUI()
	{
		GUI.Label(new Rect(Screen.width / 2 -150,200,200,50),"GAME RESULT",style);
	}
	*/
		
	void Update () {
		
		if(timerFlag){
			timer -= Time.deltaTime;
		}

		if (isDelete) {
			deleteTimer -= Time.deltaTime;
		}

		if (isUp) {
			upTimer -= Time.deltaTime;
		}

		if (isDimm) {
			dimmTimer -= Time.deltaTime;
		}

		if (dimmTimer <= 0) {
			isDimm = false;
		}
		if (setUnitFlag) {
			setUnitTimer -= 0.1f;
		}

		if (TestBlackMain != null) {
			bool move = TestBlackMain.GetComponent<TestBlack> ().MoveFlag ();
			if (move) {
				if (!timerFlag) {
					CountDownTimer ();
				}
				timerFlag = true;
				isMove = true;
				Debug.Log ("move");
			}
		} else {
			timerFlag = false;
			isMove = false;
		}

		InputControl ();
		AddUnit ();
		ReDeleteUnit ();

		if (TestBlackMain != null) {
			holdPositionX = TestBlackMain.GetComponent<TestBlack> ().TmpPosition ().x;
			holdPositionY = TestBlackMain.GetComponent<TestBlack> ().TmpPosition ().y;
		}
	}

	private void StartSetUnit(){
		SetUnitSet ();
		InitializeUnit ();
		StartDeleteMatchUnit ();
		StartUnitSet ();
	}

	private void InputControl(){
		if (!isDelete && !isUp && !isDimm && !setUnitFlag) {
			if (Input.GetMouseButtonDown (0)) {
				SetUnitSet ();
				LeftClick ();
			}

			if (Input.GetMouseButton (0) && timer > 0) {
				LeftDrag ();
			}


			if (Input.GetMouseButtonUp (0) && !isMove) {

				timer = 4.0f;
				timerFlag = false;
				LeftUp ();
				Debug.Log("test");
			}

			if (Input.GetMouseButtonUp (0) && isMove) {

				timer = 4.0f;
				timerFlag = false;
				setUnitFlag = true;
				LeftUp ();
			}

			if(timer <= 0){
				LeftUp ();
				timer = 4.0f;
				timerFlag = false;
				setUnitFlag = true;
			}
		}
		if(setUnitTimer <= 0){
			DeleteMatchUnit();
			deleteTimer = comboTimer / 2f + 0.05f;
			isLoop = true;
			isDeleteUnit = true;
			isDelete = true;

			setUnitFlag = false;
			setUnitTimer = 0.8f;
		}
	}

	//タップしたときの関数
	private void LeftClick(){
		Vector3 tapPoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, z);
		//ユニットを掴んでいない時
		if (holdObj == null) {
			//タッチした位置のユニットとの判定
			Collider2D col = Physics2D.OverlapPoint (Camera.main.ScreenToWorldPoint (tapPoint));

			//タッチした位置にユニットがいたら、ユニット、初期位置を保持
			if (col != null) {
				this.holdObj = col.gameObject;
				holdPositionX = this.holdObj.transform.position.x;
				holdPositionY = this.holdObj.transform.position.y;
				holdObj.transform.position = Camera.main.ScreenToWorldPoint (tapPoint);
				holdObj.tag = "move"; 

				this.TestBlackMain = (GameObject)Instantiate(TestBlack);
				TestBlackMain.transform.position = new Vector3(holdPositionX,holdPositionY,0);
			}
		}
	}
	
	//スワイプしたときの関数
	private void LeftDrag(){
		//現在のタッチしている位置
		Vector3 tapPoint = Input.mousePosition;

		//ユニットを掴んでいる時
		if(holdObj != null){
			//ユニットをタッチしている位置に追随するように更新
			this.holdObj.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(tapPoint.x, tapPoint.y + 25, z));

			holdObj.renderer.sortingOrder = 10;
		}
	}
	

	//離したときの関数
	private void LeftUp(){
		DeleteTimer ();
		//ユニットを掴んでいるとき
		if (holdObj != null) {
			//ユニットを元の座標に戻
			holdObj.transform.position = TestBlackMain.GetComponent<TestBlack>().TmpPosition();
			holdObj.renderer.sortingOrder = 0;
			holdObj.tag = "unit";  

			holdObj = null;
			Destroy(TestBlackMain);
		}
	}

	private void SetUnitSet()
	{
		GameObject[,] unitSet = new GameObject[UnitVerticalNum, UnitHorizonalNum];
		for (int i = 0; i < UnitVerticalNum; i++) {
			for (int j = 0; j < UnitHorizonalNum; j++) {
				Collider2D col = Physics2D.OverlapPoint (new Vector2 (FirstUnitPosX + UnitSize * j, FirstUnitPosY + UnitSize * i));
				if ("unit".Equals (col.tag) || "swap".Equals(col.tag)) {
						unitSet [i, j] = col.gameObject;	
				}
			}
		}
		this.unitSet = unitSet;
		SetUnitPosition ();
	}


	private void DeleteMatchUnit()
	{
		SetUnitSet ();
		isDelete = true;
		isMove = false;
		int cnt = 0;
		for(int i = 0; i < UnitVerticalNum; i++){
			for(int j = 0; j < UnitHorizonalNum; j++){
				cnt = CompareHorizontal(i, j, cnt);
				cnt = CompareVertical(i, j, cnt);
			}
		}
		DeleteUnit();
	}

	private int CompareHorizontal(int i,int j,int cnt)
	{
		if (j + 1 < UnitHorizonalNum) {
			Sprite nowSprite = GetSprite (this.unitSet [i, j]);
			Sprite nextSprite = GetSprite (this.unitSet [i, j + 1]);

			if (nowSprite.Equals (nextSprite)) {
				if (unitTable [i, j] > 0) {
					unitTable [i, j + 1] = unitTable [i, j];
				} else {
					int cntInUnit = ReCompareHorizontal(i,j,nowSprite);
					if(cntInUnit > 0){
						unitTable[i,j] = cntInUnit;
						unitTable[i,j+1] = cntInUnit;
					}else{
						cnt++;
						unitTable[i,j] = cnt;
						unitTable[i,j+1] = cnt;
					}
				}
			}
		}
		return cnt;
	}

	private int ReCompareHorizontal(int i,int j,Sprite baseSprite)
	{
		int result = 0;

		if (j + 1 < UnitHorizonalNum) {
			Sprite nextSprite = GetSprite (this.unitSet [i, j + 1]);
			if (baseSprite.Equals (nextSprite)) {
				if (unitTable [i, j + 1] > 0) {
					result = unitTable [i, j + 1];
				} else {
					result = ReCompareHorizontal (i, j + 1, baseSprite);
				}
			} else {
				result = 0;
			}
		} else {
			result = 0;
		}
		return result;
	}

	private int CompareVertical(int i,int j,int cnt)
	{
		for (int k = 1; i + k < UnitVerticalNum; k++) {
			Sprite nowSprite = GetSprite (this.unitSet [i, j]);
			Sprite nextSprite = GetSprite (this.unitSet [i + k, j]);
			if (nowSprite.Equals (nextSprite)) {
				if (unitTable [i, j] > 0) {
					unitTable [i + k, j] = unitTable [i, j];
				} else {
					cnt++;
					unitTable [i, j] = cnt;
					unitTable [i + k, j] = cnt;
				}
			} else {
				break;
			}
		}
		return cnt;
	}

	private Sprite GetSprite(GameObject obj){
		SpriteRenderer renderer = obj.GetComponent<SpriteRenderer>();
		return renderer.sprite;
	}

	private void DeleteUnit()
	{
		SetDeleteUnitSet ();

		for (int t = 0; t < 12; t++) {
			int temp = 0;

			comboTes = comboCount;
			for (int i = 0; i < UnitVerticalNum; i++) {
				for (int j = 0; j < UnitHorizonalNum; j++) {
					if (deleteTable [i, j] && unitSet[i,j] != null && temp == 0) {
						temp = unitTable [i, j];
					}
			
					if (deleteTable [i, j] && unitTable [i, j] == temp) {
						Destroy (this.unitSet [i, j], deleteCount / 1.7f);
						isDeleteUnit = true;

						if(comboCount == comboTes){
							comboCount++;
							comboNum++;
							comboTimer++;
							if (comboCount > 2) {
								AddCombo (new Vector3 (this.unitSet [i, j].transform.position.x, 
								                       this.unitSet [i, j].transform.position.y - UnitSize / 3.5f,
								                       z), deleteCount / 1.7f);
								AddComboNum (new Vector3 (this.unitSet [i, j].transform.position.x, 
								                          this.unitSet [i, j].transform.position.y + UnitSize / 3.5f, 
								                          z), comboNum, deleteCount / 1.7f);

								audio.Play();
							}
						}
					}
				}
			}

			for (int i = 0; i < UnitVerticalNum; i++) {
				for (int j = 0; j < UnitHorizonalNum; j++) {
					if (deleteTable [i, j] && unitTable [i, j] == temp) {
						unitSet [i, j] = null;
					}
				}
			}
			deleteCount++;
		}
	}

	private void SetDeleteUnitSet(){
		for (int i = 0; i < UnitVerticalNum; i++) {
			int cnt = 1;
			for (int j = 1; j < UnitHorizonalNum; j++) {
				if (unitTable [i, j] != 0 && unitTable [i, j - 1] == unitTable [i, j]) {
					cnt++;
					if (j == UnitHorizonalNum - 1) {
						if (cnt > 2) {
							for (int k = 0; k < cnt; k++) {
								deleteTable [i, j - k] = true;
							}
						}
						cnt = 1;
					}
				} else {
					if (cnt > 2) {
						for (int k = 1; k <= cnt; k++) {
							deleteTable [i, j - k] = true;
						}
					}

					cnt = 1;
				}
			}
		}



		for(int i = 0; i < UnitHorizonalNum; i++){
			int cnt = 1;
			for(int j = 1; j < UnitVerticalNum; j++){
				if (unitTable[j, i] != 0 && unitTable[j - 1, i] == unitTable[j, i]){
					cnt++;
					if(j == UnitVerticalNum - 1){
						if(cnt > 2){
							for(int k = 0; k < cnt; k++){
								deleteTable[j - k, i] = true;
							}
						}

						cnt = 1;
					}
				}else{
					if(cnt > 2){
						for(int k = 1; k <= cnt; k++){
							deleteTable[j - k, i] = true;
						}
					}

					cnt = 1;
				}
			}
		}
	}

	private void ReDeleteUnit()
	{
		if (isLoop && !isDelete && !isUp && isDeleteUnit) {
			isDeleteUnit = false;
			DeleteMatchUnit();
			deleteTimer = comboTimer / 2f + 0.05f;
			
			if(!isDeleteUnit){
				isLoop = false;
			}
			
			if(!isLoop){
				Dimm();
				deleteTimer = 0;
			}
		}
	}


	private void UpUnit()
	{
		for(int i = 0; i < UnitHorizonalNum; i++){
			for (int j = 0; j < UnitVerticalNum; j++) {
				for(int test = 0;test < 4;test++){
					if(unitSet[j,i] != null && j == test){
						float distance = 0;

						for(int check = 1;check < 5 - test;check++){
							if(unitSet[j + check,i] == null){
								distance += UnitSize;
							}
						}
						GameObject obj = unitSet [j, i].gameObject;
					
						Hashtable table = new Hashtable();
						table.Add("y",distance);
						table.Add("time",0.3f);
						table.Add("easeType", "linear");
						iTween.MoveBy(obj,table);
				
						unitSet [j, i] = null;
					}
				}
			}
		}
	}

	private void RecreateUnit()
	{
		for(int j = 0;j < UnitHorizonalNum;j++){
			for (int i = 0; i < UnitVerticalNum; i++) {
				if(unitSet[i,j]==null){
					createPos++;
			
					GameObject unit = (GameObject)Instantiate(unitObj);
					SpriteRenderer renderer = unit.gameObject.GetComponent<SpriteRenderer>();
					renderer.sprite = units[Random.Range(0,6)];
					Vector3 pos = new Vector3(FirstUnitPosX + UnitSize * (float)j,
					                          FirstUnitPosY - UnitSize * createPos,0);
					unit.transform.position = pos;

					float distance = 0;
				
					for(int check = 0; check < UnitVerticalNum;check++){
						if(unitSet[check,j] == null){
							distance += UnitSize;
						}
					}

					Hashtable table = new Hashtable();
					table.Add("y",distance);
					table.Add("time",0.3f);
					table.Add("easeType", "linear");
					iTween.MoveBy(unit,table);
				}
			}
			createPos = 0;
		}
	}


	private void AddUnit()
	{
		if (deleteTimer <= 0 && isDelete) {
			RecreateUnit();
			UpUnit();
			isUp = true;
			
			if(comboTimer > 0){ 
				upTimer = 0.7f;
			}else{
				upTimer = 0;
			}
			
			//init
			deleteCount = 0;
			isDelete = false;
			comboTimer = 0;
			unitTable = new int[UnitVerticalNum, UnitHorizonalNum];
			deleteTable = new bool[UnitVerticalNum, UnitHorizonalNum];
		}

		if (upTimer <= 0 && isUp) {
			isUp = false;
			upTimer = 0.7f;
			unitTable = new int[UnitVerticalNum, UnitHorizonalNum];
			deleteTable = new bool[UnitVerticalNum, UnitHorizonalNum];
		}
	}

	private void InitializeUnit()
	{
		for (int i =0; i < UnitVerticalNum; i++) {
			for(int j = 0;j < UnitHorizonalNum;j++){
				GameObject unit = unitSet[i,j];
				SpriteRenderer renderer = unit.gameObject.GetComponent<SpriteRenderer>();
				int rand = Random.Range(0,6);
				renderer.sprite = units[rand];
			}
		}
	}

	private void AddCombo(Vector3 comboPosition,float delayTime)
	{
		GameObject combo = (GameObject)Instantiate(rengeki);
		combo.GetComponent<Combo> ().init (delayTime);
		comboList.Add (combo);
		combo.transform.position = comboPosition;
	}

	private void AddComboNum(Vector3 comboNumPosition,int comboCount,float delayTime)
	{
		GameObject comboNum = (GameObject)Instantiate(comboNumObj);
		comboNum.GetComponent<Combo> ().init (delayTime);
		SpriteRenderer renderer = comboNum.gameObject.GetComponent<SpriteRenderer>();
		renderer.sprite = nums [comboCount];
		comboNumList.Add(comboNum);
		comboNum.transform.position = comboNumPosition;
	}

	private void RemoveCombo(int comboCount)
	{
		for (float com = 0; com < comboCount; com++) {
			comboList[0].GetComponent<Combo>().deleteCombo(com);
			comboList.RemoveAt (0);
		}
	}


	private void RemoveComboNum(int comboCount)
	{
		for (float com = 0; com < comboCount; com++) {
			comboNumList[0].GetComponent<Combo>().deleteCombo(com);
			comboNumList.RemoveAt (0);
		}
	}


	private void CountDownTimer()
	{
		CountTimer = (GameObject)Instantiate(countTimer);
	}

	private void DeleteTimer()
	{
		Destroy (CountTimer);
	}

	private void AddDimm(float deadTime)
	{
		GameObject addDimm = (GameObject)Instantiate(dimm);
		Destroy (addDimm,deadTime / 1.5f);
	}

	private void Dimm()
	{
		AddDimm(comboList.Count);

		dimmTimer = comboList.Count / 1.5f;
		RemoveCombo(comboList.Count);
		RemoveComboNum (comboNumList.Count);
		isDimm = true;

		//init
		comboCount = 1;
		comboTes = 1;
		comboNum = 0;
	}


	private void StartUnitSet()
	{
		bool conFlg = true;
		SetUnitSet();
		while(conFlg){
			conFlg = false;
			StartDeleteMatchUnit();
			foreach(bool deleteFlg in deleteTable){
				if(deleteFlg){
					conFlg = true;
					break;
				}
			}
			deleteTable = new bool[UnitVerticalNum, UnitHorizonalNum];
			unitTable = new int[UnitVerticalNum,UnitHorizonalNum];
		}
	}

	private void StartDeleteMatchUnit(){
		int cnt = 0;
		for(int i = 0; i < UnitVerticalNum; i++){
			for(int j = 0; j < UnitHorizonalNum; j++){
				cnt = CompareHorizontal(i, j, cnt);
				cnt = CompareVertical(i, j, cnt);
			}
		}
		
		StartDeleteTile();
	}

	private void StartDeleteTile(){
		SetDeleteUnitSet();
		for(int i = 0; i < UnitVerticalNum; i++){
			for(int j = 0; j < UnitHorizonalNum; j++){
				if(deleteTable[i, j]){
					Destroy(this.unitSet[i,j]);
				}
			}
		}
		for(int i = 0; i < UnitVerticalNum; i++){
			for(int j = 0; j < UnitHorizonalNum; j++){
				if(deleteTable[i, j]){
					unitSet[i, j] = null;
				}
			}
		}
		StartRecreateUnit();
	}
	
	private void StartRecreateUnit(){
		for(float i = 0; i < UnitVerticalNum; i++){
			for(float j = 0; j < UnitHorizonalNum; j++){
				if(unitSet[(int)i, (int)j] == null){
					GameObject unit = (GameObject)Instantiate(unitObj);
					SpriteRenderer renderer = unit.gameObject.GetComponent<SpriteRenderer>();
					renderer.sprite = units[Random.Range (0, 6)];
					Vector3 pos = new Vector3(FirstUnitPosX + UnitSize * j,FirstUnitPosY + UnitSize * i,z);
					unit.transform.position = pos;
					unitSet[(int)i, (int)j] = unit;
				}
			}
		}
	}


	private void SetUnitPosition()
	{
		for(float j = 0;j < UnitHorizonalNum;j+=1.0f){
			for (float i = 0; i < UnitVerticalNum; i+=1.0f) {
				Vector3 pos = new Vector3(FirstUnitPosX + UnitSize * j,
					                      FirstUnitPosY + UnitSize * i,0);

				unitSet[(int)i,(int)j].transform.position = pos;
				}
			}
	}
}
