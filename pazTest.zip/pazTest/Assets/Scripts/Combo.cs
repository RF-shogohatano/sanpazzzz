﻿using UnityEngine;
using System.Collections;

public class Combo : MonoBehaviour {

	private float timer = 0;
	private bool colorRed = false;
	private bool colorBule = false;
	private bool colorGreen = false;
	private float spawn = 0.2f;
	private float alpha = 0;
	private bool isFade = false;

	// Use this for initialization
	void Start () {
		renderer.material.color = new Color(0,0,0,0);
	}

	public void init(float delayTime)
	{
		Hashtable table = new Hashtable();
		table.Add("alpha",0);
		table.Add("time",0.1f);
		table.Add("delay",delayTime / 1.2f);
		table.Add("oncomplete","AlphaTes");
		table.Add ("oncompletetarget", gameObject);
			
		iTween.FadeTo (gameObject, table);

		isFade = true;
	}

	void OnGUI()
	{

	}

	void AlphaTes()
	{
		colorGreen = true;
		alpha = 1;
		iTween.ColorTo (gameObject,new Color (0, 1, 0, alpha),spawn);
	}
	
	// Update is called once per frame
	void Update () {
	
		if (isFade) {
			timer += Time.deltaTime;

			if (timer > spawn && colorGreen) {
				iTween.ColorTo (gameObject, new Color (0, 0, 1, alpha), spawn);
				colorGreen = false;
				colorBule = true;
				timer = 0;
			} else if (timer > spawn && colorBule) {
				iTween.ColorTo (gameObject, new Color (1, 0, 0, alpha), spawn);
				colorBule = false;
				colorRed = true;
				timer = 0;
			} else if (timer > spawn && colorRed) {
				iTween.ColorTo (gameObject, new Color (0, 1, 0, alpha), spawn);
				colorRed = false;
				colorGreen = true;
				timer = 0;
			}
		}
	}

	public void FadeFlag()
	{
		isFade = false;
	}

	public void deleteCombo(float com)
	{
		Hashtable table = new Hashtable();
		table.Add("x",1.5f);
		table.Add("y",1.5f);
		table.Add("time",0.3f);
		table.Add("delay",com / 1.5f);
		table.Add("onstart", "FadeFlag");
		
		Hashtable table2 = new Hashtable();
		table2.Add("alpha",0);
		table2.Add("time",0.15f);
		table2.Add("delay",com / 1.5f);

		iTween.ScaleTo(gameObject, table);
		iTween.FadeTo(gameObject,table2);

		
		Destroy (gameObject,com / 1.5f + 0.3f);
	}
}
