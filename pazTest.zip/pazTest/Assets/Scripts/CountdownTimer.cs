﻿using UnityEngine;
using System.Collections;

public class CountdownTimer : MonoBehaviour {

	private float timer = 4.0f;
	private bool colorFlag = false;
	public float interval = 0;

	// Use this for initialization
	void Start () {
	
		Hashtable table = new Hashtable ();
		table.Add ("x", 0);
		table.Add ("time", 4.0f);
		table.Add("easeType", "linear");

		renderer.material.color = Color.blue;

		iTween.ScaleBy (gameObject,table);

		iTween.ColorTo (gameObject, Color.green, 2f);

	}
	
	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;
		interval += Time.deltaTime;

		if (timer <= 0.0f) {
			Destroy(gameObject);
		}

		if (timer <= 2 && !colorFlag) {
			iTween.ColorTo(gameObject,Color.yellow,1);
			colorFlag = true;
		}

		if (timer <= 2 && timer >= 1 &&  interval > 0.1) {
			renderer.enabled = !renderer.enabled;
			interval = 0;
		}

		if (timer <= 1 && interval > 0.05f) {
			renderer.enabled = !renderer.enabled;
			interval = 0;
		}
	
	}
}
