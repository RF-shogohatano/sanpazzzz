﻿using UnityEngine;
using System.Collections;

public class fps : MonoBehaviour {

	//float time;

	GUIStyle style;

	int frameCount;
	float nextTime;

	float FPS = 0;




	public float m_updateInterval = 1.0f;  // 更新される頻度
	float m_accumulated   = 0.0f;
	float m_timeUntilNextInterval; //  次の更新までの残り時間
	int m_numFrames = 0;



	
	// Use this for initialization
	void Start () {


		nextTime = Time.time + 1;

		style = new GUIStyle();
		style.fontSize = 20;
		style.normal.textColor = Color.red;


		m_timeUntilNextInterval = m_updateInterval;
	
	}
	
	// Update is called once per frame
	void Update () {
		/*
		frameCount++;
		
		if ( Time.time >= nextTime ) {
			// 1秒経ったらFPSを表示
			Debug.Log("FPS : " + frameCount);
			frameCount = 0;
			nextTime += 1;
			guiText.text = "<Color=red>TIME:" + frameCount.ToString () + "</Color>";
		}
		*/


		m_timeUntilNextInterval -= Time.deltaTime;
		m_accumulated += Time.timeScale / Time.deltaTime;
		++m_numFrames;

		if( m_timeUntilNextInterval <= 0.0 )
		{
			// FPSの計算と表示
			FPS = m_accumulated / m_numFrames;
			string format = System.String.Format( "FPS: {0:F2}", FPS );

			Debug.Log("FPS:" + FPS);

			guiText.text = format;
			
			m_timeUntilNextInterval = m_updateInterval;
			m_accumulated = 0.0F;
			m_numFrames = 0;
		}


	}


	void OnGUI()
	{
		//GUI.Label(new Rect(Screen.width / 2 -150,200,200,50),"GAME RESULT",style);
		GUI.Label (new Rect (Screen.width / 2 - 100, 20, 200, 50), "FPS" + FPS, style);
		//GUI.Label(new Rect(Screen.width / 2 -150,300,200,50),"NOW SCORE" + now,style);
	}


}